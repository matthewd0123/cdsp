"""
SPDX-FileCopyrightText: Copyright (c) 2024 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
SPDX-FileType: SOURCE
SPDX-License-Identifier: Apache-2.0
"""
from tdk.apis.apis import TdkApis
from tdk.core.abstract_service import BaseService
from tdk.target.protofiles.ultifi.vehicle.body.mirrors.v1.mirrors_service_pb2 import (
    UntiltSideMirrorRequest,
    ActivateHeatedSideMirrorRequest,
    DeactivateHeatedSideMirrorRequest,
    UpdateAutoFoldSideMirrorsSettingsRequest,
    UpdateHeatedSideMirrorsSettingsRequest,
    UpdateAutoTiltSideMirrorsSettingsRequest

)

from tdk.helper.transport_configuration import TransportConfiguration


class BodyMirrorsService(BaseService):
    def __init__(self, portal_callback=None, transport_config: TransportConfiguration = None, tdk_apis: TdkApis = None):
        """
        BodyMirrorsService constructor
        """
        super().__init__("body.mirrors", portal_callback, transport_config, tdk_apis)
        self.init_state()

    def init_state(self):
        """
        Initializes internal data structures for keeping track of the current state of the BodyMirrorsService
        """
        self.state = {}

    # RPC Request Listeners for each RPC method

    @BaseService.request_listener
    def UntiltSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def ActivateHeatedSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def DeactivateHeatedSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UpdateAutoFoldSideMirrorsSettings(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UpdateHeatedSideMirrorsSettings(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UpdateAutoTiltSideMirrorsSettings(self, request, response):
        return self.handle_request(request, response)

    def handle_request(self, request, response):
        # handle UntiltSideMirror request
        if isinstance(request, UntiltSideMirrorRequest):
            # todo return UntiltSideMirrorResponse response, Implement your logic here
            pass

        # handle ActivateHeatedSideMirror request
        if isinstance(request, ActivateHeatedSideMirrorRequest):
            # todo return ActivateHeatedSideMirrorResponse response, Implement your logic here
            pass

        # handle DeactivateHeatedSideMirror request
        if isinstance(request, DeactivateHeatedSideMirrorRequest):
            # todo return DeactivateHeatedSideMirrorResponse response, Implement your logic here
            pass

        # handle UpdateAutoFoldSideMirrorsSettings request
        if isinstance(request, UpdateAutoFoldSideMirrorsSettingsRequest):
            # todo return UpdateAutoFoldSideMirrorsSettingsResponse response, Implement your logic here
            pass

        # handle UpdateHeatedSideMirrorsSettings request
        if isinstance(request, UpdateHeatedSideMirrorsSettingsRequest):
            # todo return UpdateHeatedSideMirrorsSettingsResponse response, Implement your logic here
            pass

        # handle UpdateAutoTiltSideMirrorsSettings request
        if isinstance(request, UpdateAutoTiltSideMirrorsSettingsRequest):
            # todo return UpdateAutoTiltSideMirrorsSettingsResponse response, Implement your logic here
            pass

        response.code.code = 0
        response.code.message = "OK"
        return response


if __name__ == "__main__":
    config = TransportConfiguration()
    config.set_zenoh_config("10.0.0.33", 9090)  # this will set the zenoh helper
    tdk_apis = TdkApis(config)
    service = BodyMirrorsService(tdk_apis=tdk_apis, transport_config=config)
    service.start()
