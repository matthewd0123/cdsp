"""
SPDX-FileCopyrightText: Copyright (c) 2024 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
SPDX-FileType: SOURCE
SPDX-License-Identifier: Apache-2.0
"""

from tdk.apis.apis import TdkApis
from tdk.core.abstract_service import BaseService
from tdk.helper.transport_configuration import TransportConfiguration
from tdk.target.protofiles.vehicle.body.mirrors.v1.mirrors_service_pb2 import (
    ActivateHeatedSideMirrorRequest,
    DeactivateHeatedSideMirrorRequest,
    FoldSideMirrorRequest,
    SlideSideMirrorRequest,
    TiltSideMirrorRequest,
    UnfoldSideMirrorRequest,
    UntiltSideMirrorRequest,
    UpdateHeatedSideMirrorsSettingsRequest,
    UpdateSideMirrorMovementSettingsRequest,
)


class BodyMirrorsService(BaseService):
    def __init__(self, portal_callback=None, transport_config: TransportConfiguration = None, tdk_apis: TdkApis = None):
        """
        BodyMirrorsService constructor
        """
        super().__init__("body.mirrors", portal_callback, transport_config, tdk_apis)
        self.init_state()

    def init_state(self):
        """
        Initializes internal data structures for keeping track of the current state of the BodyMirrorsService
        """
        self.state = {}

    # RPC Request Listeners for each RPC method
    @BaseService.request_listener
    def SlideSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def FoldSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UnfoldSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def TiltSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UntiltSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def ActivateHeatedSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def DeactivateHeatedSideMirror(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UpdateSideMirrorMovementSettings(self, request, response):
        return self.handle_request(request, response)

    @BaseService.request_listener
    def UpdateHeatedSideMirrorsSettings(self, request, response):
        return self.handle_request(request, response)

    def handle_request(self, request, response):
        # handle SlideSideMirror request
        if isinstance(request, SlideSideMirrorRequest):
            # todo return SlideSideMirrorResponse response, Implement your logic here
            pass

        # handle FoldSideMirror request
        if isinstance(request, FoldSideMirrorRequest):
            # todo return FoldSideMirrorResponse response, Implement your logic here
            pass

        # handle UnfoldSideMirror request
        if isinstance(request, UnfoldSideMirrorRequest):
            # todo return UnfoldSideMirrorResponse response, Implement your logic here
            pass

        # handle TiltSideMirror request
        if isinstance(request, TiltSideMirrorRequest):
            # todo return TiltSideMirrorResponse response, Implement your logic here
            pass

        # handle UntiltSideMirror request
        if isinstance(request, UntiltSideMirrorRequest):
            # todo return UntiltSideMirrorResponse response, Implement your logic here
            pass

        # handle ActivateHeatedSideMirror request
        if isinstance(request, ActivateHeatedSideMirrorRequest):
            # todo return ActivateHeatedSideMirrorResponse response, Implement your logic here
            pass

        # handle DeactivateHeatedSideMirror request
        if isinstance(request, DeactivateHeatedSideMirrorRequest):
            # todo return DeactivateHeatedSideMirrorResponse response, Implement your logic here
            pass

        # handle UpdateSideMirrorMovementSettings request
        if isinstance(request, UpdateSideMirrorMovementSettingsRequest):
            # todo return UpdateSideMirrorMovementSettingsResponse response, Implement your logic here
            pass

        # handle UpdateHeatedSideMirrorsSettings request
        if isinstance(request, UpdateHeatedSideMirrorsSettingsRequest):
            # todo return UpdateHeatedSideMirrorsSettingsResponse response, Implement your logic here
            pass
        response.code.code = 0
        response.code.message = "OK"
        return response


if __name__ == "__main__":
    service = BodyMirrorsService()
    service.start()
